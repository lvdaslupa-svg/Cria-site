CRIASITE — SITE COM RECEBIMENTO DE ORÇAMENTOS POR E-MAIL
============================================================

O QUE MUDOU
- O visitante preenche as 4 etapas com nome, WhatsApp, preferências, pacote,
  funcionalidades, descrição, referências, manutenção e observações.
- Ao clicar ENVIAR PEDIDO POR E-MAIL, o formulário envia automaticamente os
  dados ao e-mail configurado, sem abrir o aplicativo WhatsApp do visitante.
- O cliente escolhe como prefere receber o retorno (WhatsApp, e-mail ou ligação).
- Após a confirmação do servidor, aparece uma mensagem de sucesso e opção
  opcional de falar no WhatsApp comercial, caso o número esteja configurado.
- Em caso de falha no envio, o cliente mantém os dados e pode tentar novamente.
- Os botões de copiar e baixar o briefing continuam como alternativa.

PARA HABILITAR O RECEBIMENTO AUTOMÁTICO (OBRIGATÓRIO)
1. Extraia os arquivos ZIP e abra o arquivo config.js.
2. Preencha emailOrcamentos: 'SEU_EMAIL@SEU_DOMINIO.COM'
3. (Opcional) Preencha whatsappComercial com '55' + DDD + número.
4. Publique os arquivos do site juntos (Netlify, Vercel, GitHub Pages etc.).
5. Faça o PRIMEIRO pedido de teste usando o formulário publicado.
6. Abra sua caixa de entrada e o spam. O FormSubmit enviará um convite para
   verificar/ATIVAR seu endereço de recebimento; clique no link de ativação.
7. Faça um SEGUNDO pedido e CONFIRME o recebimento com todos os campos.
   Não anuncie o site antes deste teste final.

O envio usa serviço de terceiros FormSubmit.co (requisições AJAX).
Saiba mais: https://formsubmit.co/documentation

ATENÇÃO / LIMITES
- Não há ENVIO REAL enquanto emailOrcamentos estiver vazio, o endereço não
  tiver sido confirmado e o site não estiver publicado/testado.
- O endereço de recebimento está visível no código do site. Para manter o
  e-mail privado, será necessário usar um servidor ou integração com ID.
- Não use senhas SMTP, chaves de APIs privadas ou outros segredos no config.js.
- A informação do cliente é transmitida ao serviço FormSubmit, que processa
  os envios; revise a política de privacidade antes de publicar.
- O formulário não realiza pagamento, cobrança de mensalidade, criação automática
  de site, ou envio automático de WhatsApp pela empresa.
- O serviço de formulários pode limitar envios suspeitos/spam. Usa-se um campo
  oculto para limitar bots; consulte as regras do FormSubmit.
- Os preços dos pacotes são referenciais e precisam ser revisados antes da venda.

PREÇOS SUGERIDOS
Criação: Start 499; Profissional 999; Loja Virtual 1999.
Manutenção: Essencial 89/mês; Profissional 179/mês; Premium 299/mês.

COMO ABRIR
Abra index.html para visualizar. Para envio, prefira testar após
publicar em uma hospedagem com HTTPS.
