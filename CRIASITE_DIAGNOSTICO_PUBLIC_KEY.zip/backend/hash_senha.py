"""Execute localmente: python hash_senha.py; configure SOMENTE o hash no servidor."""
import getpass
from store import hash_password
senha=getpass.getpass('Escolha sua senha do administrador (mínimo 12 caracteres): ')
if len(senha)<12: raise SystemExit('Use pelo menos 12 caracteres.')
print('\nCRIASITE_ADMIN_PASSWORD_HASH=' + hash_password(senha))
print('Não coloque sua senha em nenhum arquivo público ou no chat.')
