"""Testes API sem Mercado Pago real. Execute: python -m unittest test_admin.py"""
import os
import tempfile
import unittest

TEMP=tempfile.TemporaryDirectory()
os.environ['CRIASITE_DB_PATH'] = TEMP.name+'/criasite_test.sqlite3'
os.environ['CRIASITE_COOKIE_SECURE']='false'
os.environ['CRIASITE_ADMIN_USER']='admin_test'
from store import hash_password
os.environ['CRIASITE_ADMIN_PASSWORD_HASH']=hash_password('senha-de-teste-extremamente-forte')
from app import app
from store import install
install()
from fastapi.testclient import TestClient

class TestAdminCatalog(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client=TestClient(app,base_url='http://localhost')

    def test_no_default_access(self):
        self.assertEqual(self.client.get('/api/admin/catalogo').status_code,401)
        self.assertEqual(self.client.get('/admin').status_code,200)

    def test_login_catalog_and_coupons(self):
        client=TestClient(app,base_url='http://localhost')
        self.assertEqual(client.post('/api/admin/login',json={'usuario':'admin_test','senha':'errada'}).status_code,401)
        response=client.post('/api/admin/login',json={'usuario':'admin_test','senha':'senha-de-teste-extremamente-forte'})
        self.assertEqual(response.status_code,200)
        self.assertIn('httponly',response.headers.get('set-cookie','').lower())
        csrf=response.json()['csrf_token']
        auth={'x-csrf-token':csrf}
        self.assertEqual(client.get('/api/admin/me').status_code,200)
        self.assertEqual(client.put('/api/admin/catalogo/start',json={}).status_code,403)
        prod=client.get('/api/admin/catalogo').json()[0]
        self.assertEqual(prod['id'],'start')
        resp=client.put('/api/admin/catalogo/start',headers=auth,json={'nome':'Start Premium','descricao':'Nova descrição','preco_centavos':39900,'preco_original_centavos':49900,'ativo':True})
        self.assertEqual(resp.status_code,200,resp.text)
        creation=[x for x in client.get('/api/catalogo').json() if x['id']=='start'][0]
        self.assertEqual(creation['preco_centavos'],39900)
        r=client.post('/api/admin/cupons',headers=auth,json={'codigo':'BEMVINDO10','tipo':'percent','valor':10,'valido_ate':None,'limite_usos':3})
        self.assertEqual(r.status_code,200,r.text)
        preview=client.post('/api/checkout/previa',json={'pacote':'start','manutencao':'plus','cupom':'BEMVINDO10'})
        self.assertEqual(preview.status_code,200,preview.text)
        self.assertEqual(preview.json()['desconto_centavos'],3990)
        self.assertEqual(preview.json()['criacao_com_desconto_centavos'],35910)
        self.assertEqual(preview.json()['manutencao_centavos'],17900)
        r=client.patch('/api/admin/cupons/BEMVINDO10',json={'ativo':False},headers=auth)
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(client.post('/api/checkout/previa',json={'pacote':'start','cupom':'BEMVINDO10'}).status_code,400)
        self.assertEqual(client.post('/api/admin/logout',headers=auth).status_code,200)
        self.assertEqual(client.get('/api/admin/catalogo').status_code,401)

    def test_fixed_coupon_expiration(self):
        from store import connect
        with connect() as db:
            db.execute("INSERT OR REPLACE INTO cupons (codigo,tipo,valor,valido_ate,ativo) VALUES ('VENCIDO','fixed',1000,'2020-01-01',1)")
            db.execute("INSERT OR REPLACE INTO cupons (codigo,tipo,valor,ativo) VALUES ('FIXO50','fixed',5000,1)")
        self.assertEqual(self.client.post('/api/checkout/previa',json={'pacote':'pro','cupom':'VENCIDO'}).status_code,400)
        x=self.client.post('/api/checkout/previa',json={'pacote':'pro','cupom':'FIXO50'}).json()
        self.assertEqual(x['desconto_centavos'],5000)
        self.assertEqual(x['criacao_com_desconto_centavos'],94900)

if __name__=='__main__': unittest.main()
