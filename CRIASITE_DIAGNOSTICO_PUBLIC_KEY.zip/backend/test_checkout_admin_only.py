"""Valida que ensaios com credenciais de teste não abrem o checkout para o público."""
import os
import unittest
from unittest.mock import Mock, patch
from fastapi import HTTPException
import checkout_mp

class AdminOnlyTest(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {
            'CRIASITE_ENABLE_CHECKOUT':'false',
            'CRIASITE_PERSISTENT_STORAGE_CONFIRMED':'false',
            'CRIASITE_TEST_CHECKOUT':'true',
            'DATABASE_URL':'postgresql://placeholder/db',
            'MP_PUBLIC_KEY':'TEST_PUBLIC_KEY',
            'MP_ACCESS_TOKEN':'TEST_PRIVATE_TOKEN',
            'MP_WEBHOOK_SECRET':'TEST_SIGNING_KEY'
        })
        self.env.start()
        self.addCleanup(self.env.stop)
        self.request = Mock()

    @patch('checkout_mp.store.session_from_request', return_value={'usuario':'admin','csrf_token':'abc'})
    def test_admin_can_open_test_only(self, sess):
        self.assertEqual(checkout_mp.checkout_access(self.request),('teste', {'usuario':'admin','csrf_token':'abc'}))
        self.assertEqual(checkout_mp.config(self.request)['ambiente'],'teste')

    @patch('checkout_mp.store.session_from_request', side_effect=HTTPException(401,'No login'))
    def test_public_stays_disabled(self, sess):
        with self.assertRaises(HTTPException) as cm:
            checkout_mp.checkout_access(self.request,write=True)
        self.assertEqual(cm.exception.status_code,503)
        self.assertFalse(checkout_mp.config(self.request)['pronto'])

    @patch('checkout_mp.store.session_from_request', return_value={'usuario':'admin','csrf_token':'abc'})
    def test_mutations_require_csrf(self,sess):
        checkout_mp.checkout_access(self.request,write=True)
        self.assertTrue(sess.call_args.kwargs['csrf'])

    @patch('checkout_mp.store.session_from_request', return_value={'usuario':'admin','csrf_token':'abc'})
    def test_test_disabled_by_default(self,sess):
        os.environ['CRIASITE_TEST_CHECKOUT']='false'
        self.assertFalse(checkout_mp.config(self.request)['pronto'])
        sess.assert_not_called()

if __name__=='__main__':unittest.main()
