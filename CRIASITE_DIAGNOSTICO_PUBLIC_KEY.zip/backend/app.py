"""CRIASITE: acompanhamento automático de manutenção (NÃO suspende o site).

Backend de referência. Deploy HTTPS, PostgreSQL, autenticação robusta, backups,
observabilidade e validação da integração são necessários antes da produção.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import sqlite3
import db_compat
import urllib.parse
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException, Request, Depends, Header
import store
import checkout_mp
from pydantic import BaseModel, Field

DB = Path(os.getenv("CRIASITE_DB_PATH", str(Path(__file__).parent / "data.sqlite3")))
API_URL = "https://api.mercadopago.com"
MP_TOKEN = os.getenv("MP_ACCESS_TOKEN", "").strip()
MP_SECRET = os.getenv("MP_WEBHOOK_SECRET", "").strip()
ADMIN_KEY = os.getenv("CRIASITE_ADMIN_KEY", "").strip()
GRACE_HOURS = max(0, float(os.getenv("CRIASITE_GRACE_HOURS", "0")))
app = FastAPI(title="CRIASITE - Manutenção por assinatura", version="0.1.0")


def db():
    return db_compat.connect(os.getenv('CRIASITE_DB_PATH', str(DB)))


def init_db():
    with db() as c:
        db_compat.create_subscription_tables(c)

def _pg_unique_violation():
    if db_compat.is_postgres():
        from psycopg.errors import UniqueViolation
        return UniqueViolation
    return sqlite3.IntegrityError

init_db()
store.attach(app)
checkout_mp.init()
app.include_router(checkout_mp.router)


class ClienteEntrada(BaseModel):
    nome: str = Field(min_length=2, max_length=120)
    email: str = Field(default="", max_length=180)
    whatsapp: str = Field(default="", max_length=32)
    plano: str = Field(pattern="^(basic|plus|premium)$")
    subscription_id: str = Field(min_length=5, max_length=160, pattern=r"^[a-zA-Z0-9_-]+$")


def admin(request: Request, authorization: Optional[str] = Header(default=None)):
    if request.cookies.get("criasite_session"):
        store.session_from_request(request, csrf=True)
        return
    if not ADMIN_KEY:
        raise HTTPException(503, "Configure CRIASITE_ADMIN_KEY no servidor")
    provided = (authorization or "").removeprefix("Bearer ")
    if not hmac.compare_digest(provided, ADMIN_KEY):
        raise HTTPException(401, "Acesso negado")


def iso_date(value):
    if not value: return None
    try:
        date = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return date if date.tzinfo else date.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def evaluate(subscription, invoices, now=None, grace_hours=0):
    """Regra de negócio: SOMENTE a manutenção; website permanece publicado.

    Falha de API não é parâmetro desta função e jamais deve causar suspensão.
    Contabiliza cada parcela vencida; cobrança ainda processando é 'verificando'.
    """
    now = now or datetime.now(timezone.utc)
    state = str(subscription.get("status") or "").lower()
    if state in ("canceled", "cancelled"):
        return "cancelado", "Assinatura cancelada no Mercado Pago"
    if state in ("paused",):
        return "suspenso", "Assinatura pausada no Mercado Pago"
    if state != "authorized":
        return "verificando", f"Assinatura ainda não autorizada ({state or 'sem status'})"
    valid = [item for item in invoices if item.get("preapproval_id") == subscription.get("id")]
    due = []
    for inv in valid:
        debit = iso_date(inv.get("debit_date"))
        if debit and debit <= now:
            due.append((debit, inv))
    due.sort(key=lambda pair: pair[0])
    if not due:
        return "verificando", "Aguardando primeira parcela e sua confirmação"

    unpaid = []
    processing = []
    payments_ok = 0
    for debit, inv in due:
        payment = inv.get("payment") or {}
        payment_status = str(payment.get("status") or "").lower()
        summarized = str(inv.get("summarized") or "").lower()
        bill_status = str(inv.get("status") or "").lower()
        if payment_status == "approved":
            payments_ok += 1
            continue
        # Enquanto o gateway ainda avalia o pagamento, não suspender precipitadamente.
        if bill_status in ("waiting for gateway", "waiting_for_gateway") or payment_status in ("in_process", "in_mediation"):
            processing.append(str(inv.get("id")))
            continue
        if now >= debit + timedelta(hours=grace_hours):
            unpaid.append(str(inv.get("id")))
        else:
            processing.append(str(inv.get("id")))

    if unpaid:
        return "suspenso", "Parcela(s) vencida(s) sem pagamento aprovado: " + ", ".join(unpaid)
    if processing:
        return "verificando", "Pagamento(s) pendente(s) de confirmação: " + ", ".join(processing)
    if payments_ok:
        return "ativo", "Parcelas vencidas identificadas como pagas"
    return "verificando", "Sem comprovação de pagamento"


async def mp_get(path: str, params: Optional[dict] = None):
    if not MP_TOKEN:
        raise HTTPException(503, "Configure MP_ACCESS_TOKEN somente no servidor")
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            res = await client.get(API_URL + path, params=params,
                                   headers={"Authorization": f"Bearer {MP_TOKEN}"})
            res.raise_for_status()
            return res.json()
    except (httpx.HTTPError, ValueError) as ex:
        raise HTTPException(503, "Não foi possível confirmar o pagamento com Mercado Pago; status preservado") from ex


async def get_invoices(subscription_id):
    # Paginação pequena; em volume alto, usar serviço de reconciliação em fila.
    invoices = []
    for offset in range(0, 300, 100):
        obj = await mp_get("/authorized_payments/search", {"preapproval_id": subscription_id, "limit": 100, "offset": offset})
        chunk = obj.get("results", [])
        invoices.extend(chunk)
        if len(chunk) < 100: break
    return invoices


async def reconcile(subscription_id):
    with db() as c:
        client = c.execute("SELECT * FROM clientes WHERE subscription_id=?", (subscription_id,)).fetchone()
    if client is None:
        return {"ignored": True, "message": "Assinatura não cadastrada"}
    # Primeiro buscar provas diretamente do MP; se falhar, NUNCA alterar estado.
    sub = await mp_get("/preapproval/" + urllib.parse.quote(subscription_id, safe=""))
    if str(sub.get("id")) != subscription_id:
        raise HTTPException(503, "Identificação da assinatura não confirmada")
    invoices = await get_invoices(subscription_id)
    new_status, reason = evaluate(sub, invoices, grace_hours=GRACE_HOURS)
    with db() as c:
        old = c.execute("SELECT * FROM clientes WHERE subscription_id=?", (subscription_id,)).fetchone()
        if old is None: return {"ignored": True}
        if old["status"] != new_status or old["motivo"] != reason:
            c.execute("UPDATE clientes SET status=?,motivo=?,atualizado_em=CURRENT_TIMESTAMP WHERE id=?",
                      (new_status, reason, old["id"]))
            if old["status"] != new_status:
                c.execute("INSERT INTO historico(cliente_id,status_anterior,status_novo,motivo) VALUES(?,?,?,?)",
                          (old["id"], old["status"], new_status, reason))
    return {"subscription_id": subscription_id, "status": new_status, "motivo": reason,
            "site_publicado": True, "servico_suspenso": new_status in ("suspenso", "cancelado")}


def verify_webhook(request: Request, data_id: str):
    if not MP_SECRET:
        raise HTTPException(503, "Configure MP_WEBHOOK_SECRET no servidor")
    signature = request.headers.get("x-signature", "")
    request_id = request.headers.get("x-request-id", "")
    parts = dict(piece.strip().split("=", 1) for piece in signature.split(",") if "=" in piece)
    ts, received = parts.get("ts", ""), parts.get("v1", "")
    if not (request_id and data_id and ts and received):
        raise HTTPException(401, "Assinatura ausente")
    manifest = f"id:{data_id};request-id:{request_id};ts:{ts};"
    expected = hmac.new(MP_SECRET.encode(), manifest.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(received.lower(), expected):
        raise HTTPException(401, "Assinatura inválida")


@app.get("/api/health")
def health():
    return {"ok": True, "mp_credential_configured": bool(MP_TOKEN), "webhook_secret_configured": bool(MP_SECRET)}


@app.post("/api/admin/clientes", dependencies=[Depends(admin)])
def create_client(customer: ClienteEntrada):
    with db() as c:
        try:
            cur = c.execute("INSERT INTO clientes(nome,email,whatsapp,plano,subscription_id) VALUES (?,?,?,?,?)",
                            (customer.nome, customer.email, customer.whatsapp, customer.plano, customer.subscription_id))
        except (sqlite3.IntegrityError, _pg_unique_violation()):
            raise HTTPException(409, "Assinatura já cadastrada")
    return {"id": cur.lastrowid, "status": "verificando", "nota": "Use /api/admin/sincronizar para consultar os pagamentos"}


@app.get("/api/admin/clientes", dependencies=[Depends(admin)])
def list_clients():
    with db() as c:
        rows = c.execute("SELECT * FROM clientes ORDER BY id DESC").fetchall()
    return [dict(row) for row in rows]


@app.get("/api/admin/historico", dependencies=[Depends(admin)])
def history():
    with db() as c:
        rows = c.execute("SELECT * FROM historico ORDER BY id DESC LIMIT 300").fetchall()
    return [dict(row) for row in rows]


@app.post("/api/admin/sincronizar/{subscription_id}", dependencies=[Depends(admin)])
async def sync_one(subscription_id: str):
    if not subscription_id.isascii() or not all(c.isalnum() or c in "_-" for c in subscription_id):
        raise HTTPException(400, "Identificador inválido")
    return await reconcile(subscription_id)


@app.post("/api/admin/sincronizar", dependencies=[Depends(admin)])
async def sync_all():
    with db() as c:
        ids = [row[0] for row in c.execute("SELECT subscription_id FROM clientes").fetchall()]
    results = []
    for subscription_id in ids:
        try:
            results.append(await reconcile(subscription_id))
        except HTTPException:
            results.append({"subscription_id": subscription_id, "error": "API indisponível: status anterior preservado"})
    return results


@app.post("/api/webhooks/mercadopago")
async def mp_webhook(request: Request):
    # NÃO confiar em payload como prova de pagamento: ele apenas dispara consulta autenticada.
    try:
        payload = await request.json()
    except ValueError:
        payload = {}
    data_id = request.query_params.get("data.id") or (payload.get("data") or {}).get("id")
    data_id = str(data_id or "")
    verify_webhook(request, data_id)
    event_type = str(payload.get("type") or payload.get("topic") or "")
    subscription_id = None
    if event_type == "subscription_preapproval":
        subscription_id = data_id
    elif event_type == "subscription_authorized_payment":
        if not data_id.isdecimal(): raise HTTPException(400, "ID de parcela inválido")
        invoice = await mp_get("/authorized_payments/" + data_id)
        subscription_id = str(invoice.get("preapproval_id") or "")
    elif event_type == "payment":
        result = await checkout_mp.process_payment(data_id, mp_get)
        if result.get('tipo') != 'não relacionado a criação':
            return result
        # Pagamentos de parcelas antigas de manutenção continuam conciliáveis.
        result = await mp_get("/authorized_payments/search", {"payment_id": data_id})
        candidates = result.get("results") or []
        for item in candidates:
            sid = item.get("preapproval_id")
            if sid:
                await reconcile(str(sid))
        return {"ok": True, "processed": len(candidates)}
    else:
        return {"ok": True, "ignored": "Tipo não relacionado a mensalidades"}
    if subscription_id:
        await reconcile(subscription_id)
    return {"ok": True}

@app.get('/painel')
def painel():
    from fastapi.responses import FileResponse
    # A página pode ser servida publicamente; todas as informações e ações
    # são protegidas por CRIASITE_ADMIN_KEY na API.
    return FileResponse(Path(__file__).with_name('painel.html'))

@app.get('/api/admin/servico/{cliente_id}', dependencies=[Depends(admin)])
def service_allowed(cliente_id: int):
    """Para sistemas de chamados e agendas: bloquear somente trabalho de manutenção.

    Não retorna dados de cartão e nunca toma nenhuma ação no site hospedado.
    """
    with db() as c:
        rec = c.execute('SELECT id,nome,status,motivo FROM clientes WHERE id=?', (cliente_id,)).fetchone()
    if rec is None:
        raise HTTPException(404, 'Cliente não encontrado')
    return {'cliente_id': rec['id'], 'nome': rec['nome'], 'status': rec['status'],
            'manutencao_autorizada': rec['status'] == 'ativo',
            'site_continua_online': True, 'motivo': rec['motivo']}

# Mesma origem: serve o site e a API juntos, para que cupom e painel funcionem.
from fastapi.staticfiles import StaticFiles
app.mount('/', StaticFiles(directory=Path(__file__).parent.parent / 'site', html=True), name='site')
