"""Execute: python -m unittest tests.py"""
import unittest
from datetime import datetime, timedelta, timezone
from app import evaluate

NOW = datetime(2026,10,16,15,0,tzinfo=timezone.utc)
SUB = {"status":"authorized", "id":"assina_123"}

def bill(hours=-6, payment='approved', status='processed', ident=5):
    return {"id":ident,"preapproval_id":"assina_123","debit_date":(NOW+timedelta(hours=hours)).isoformat(),
            "status":status,"payment":{"status":payment}}

class TestMaintenance(unittest.TestCase):
    def test_paid_is_active(self):
        self.assertEqual(evaluate(SUB,[bill()],NOW)[0],'ativo')
    def test_unpaid_is_suspended(self):
        self.assertEqual(evaluate(SUB,[bill(payment='rejected')],NOW)[0],'suspenso')
    def test_paid_reactivation(self):
        past=evaluate(SUB,[bill(payment='rejected')],NOW)[0]
        current=evaluate(SUB,[bill(payment='approved')],NOW)[0]
        self.assertEqual((past,current),('suspenso','ativo'))
    def test_still_processing(self):
        self.assertEqual(evaluate(SUB,[bill(payment='pending',status='waiting for gateway')],NOW)[0],'verificando')
    def test_future_payment_no_unpaid(self):
        self.assertEqual(evaluate(SUB,[bill(hours=5,payment='pending')],NOW)[0],'verificando')
    def test_grace_period(self):
        self.assertEqual(evaluate(SUB,[bill(hours=-1,payment='rejected')],NOW,grace_hours=4)[0],'verificando')
    def test_arrears_even_if_latest_paid(self):
        self.assertEqual(evaluate(SUB,[bill(hours=-744,payment='rejected',ident=1),bill(hours=-1,payment='approved',ident=2)],NOW)[0],'suspenso')
    def test_paused(self):
        self.assertEqual(evaluate({**SUB,'status':'paused'},[],NOW)[0],'suspenso')
    def test_cancelled(self):
        self.assertEqual(evaluate({**SUB,'status':'canceled'},[],NOW)[0],'cancelado')
    def test_unrelated_invoice(self):
        self.assertEqual(evaluate(SUB,[{**bill(),'preapproval_id':'not_ours'}],NOW)[0],'verificando')

if __name__=='__main__':unittest.main()
