"""Testes offline da camada SQL. Não usam credenciais do Supabase."""
import unittest
from unittest.mock import Mock
import db_compat


class TestPostgresAdapter(unittest.TestCase):
    def test_sql_placeholders(self):
        sql = "SELECT * FROM clientes WHERE id=? AND status=?"
        self.assertEqual(db_compat.translate_sql(sql),
                         "SELECT * FROM clientes WHERE id=%s AND status=%s")

    def test_conflicts(self):
        self.assertIn('ON CONFLICT (id) DO NOTHING',
            db_compat.translate_sql('INSERT OR IGNORE INTO catalogo (id) VALUES (?)'))
        self.assertIn('ON CONFLICT (ip_hash) DO UPDATE',
            db_compat.translate_sql('INSERT OR REPLACE INTO tentativas_login VALUES(?,?,?)'))

    def test_row_compatibility(self):
        row = db_compat.Row({'id': 123, 'nome': 'Teste'})
        self.assertEqual(row[0], 123)
        self.assertEqual(row['nome'], 'Teste')
        self.assertEqual(dict(row)['nome'], 'Teste')

    def test_rewrite_rowid(self):
        self.assertEqual(db_compat.translate_sql('ORDER BY rowid'), 'ORDER BY id')

    def test_local_without_database_url(self):
        import os
        from unittest.mock import patch
        with patch.dict(os.environ, {'DATABASE_URL':''}):
            self.assertFalse(db_compat.is_persistent())


if __name__=='__main__': unittest.main()
