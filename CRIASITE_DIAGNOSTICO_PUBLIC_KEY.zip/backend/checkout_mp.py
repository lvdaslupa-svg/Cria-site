"""Checkout transparente (Payment Brick) para criação de sites, com preço no servidor.
Desligado por padrão. Jamais habilite sem dados persistentes e testes reais homologados.
"""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from uuid import uuid4
import os
import re
import httpx
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
import store
import db_compat

router = APIRouter()
MP_API = 'https://api.mercadopago.com'


def ready():
    return (os.getenv('CRIASITE_ENABLE_CHECKOUT') == 'true'
            and db_compat.is_persistent()
            and os.getenv('CRIASITE_PERSISTENT_STORAGE_CONFIRMED') == 'true'
            and bool(os.getenv('MP_PUBLIC_KEY', '').strip())
            and bool(os.getenv('MP_ACCESS_TOKEN', '').strip())
            and bool(os.getenv('MP_WEBHOOK_SECRET', '').strip()))


def test_checkout(request: Request, write=False):
    """Ensaio isolado: login de administrador + CSRF nas chamadas que alteram dados.

    Nunca habilitar com credenciais de produção. Nenhum acesso público é liberado.
    """
    if not (os.getenv('CRIASITE_TEST_CHECKOUT') == 'true'
            and db_compat.is_persistent()
            and bool(os.getenv('MP_PUBLIC_KEY', '').strip())
            and bool(os.getenv('MP_ACCESS_TOKEN', '').strip())
            and bool(os.getenv('MP_WEBHOOK_SECRET', '').strip())):
        return None
    try:
        return store.session_from_request(request, csrf=write)
    except HTTPException:
        return None


def checkout_access(request: Request, write=False):
    if ready():
        return 'producao', None
    session = test_checkout(request, write=write)
    if session:
        return 'teste', session
    raise HTTPException(503, 'Checkout não liberado para o público; entre como administrador para o ambiente de teste.')


def init():
    with store.connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS pedidos (
            id TEXT PRIMARY KEY, nome TEXT NOT NULL, email TEXT NOT NULL,
            whatsapp TEXT NOT NULL, pacote TEXT NOT NULL, valor_centavos INTEGER NOT NULL,
            cupom TEXT, desconto_centavos INTEGER NOT NULL DEFAULT 0,
            briefing TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'aguardando_pagamento',
            mp_preference_id TEXT, mp_payment_id TEXT UNIQUE,
            criado_em TEXT NOT NULL, expira_em TEXT NOT NULL,
            atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_pedidos_cupom ON pedidos(cupom,status,expira_em)')


class CheckoutRequest(BaseModel):
    pacote: str = Field(pattern='^(start|pro|store)$')
    cupom: str = Field(default='', max_length=24)
    nome: str = Field(min_length=2, max_length=120)
    email: str = Field(min_length=5, max_length=180)
    whatsapp: str = Field(min_length=10, max_length=30)
    briefing: str = Field(min_length=20, max_length=14000)
    aceitou_termos: bool


@router.get('/api/checkout/config')
def config(request: Request):
    if ready():
        return {'pronto': True, 'modo': 'payment_brick', 'ambiente': 'producao',
                'metodos': ['pix', 'cartao'], 'mensagem': 'Checkout integrado disponível'}
    session = test_checkout(request)
    if session:
        return {'pronto': True, 'modo': 'payment_brick', 'ambiente': 'teste',
                'csrf_token': session['csrf_token'], 'metodos': ['pix', 'cartao'],
                'mensagem': 'TESTE APENAS PARA ADMINISTRADOR — não use cartão real.'}
    return {'pronto': False, 'modo': 'payment_brick', 'metodos': ['pix', 'cartao'],
            'mensagem': 'Pagamento de criação ainda não liberado.'}


@router.post('/api/checkout/criar')
async def create_checkout(body: CheckoutRequest, request: Request):
    checkout_access(request, write=True)
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', body.email):
        raise HTTPException(422, 'Informe um e-mail válido para receber notícias do pedido')
    whatsapp = re.sub(r'\D', '', body.whatsapp)
    if not 10 <= len(whatsapp) <= 13:
        raise HTTPException(422, 'Informe um WhatsApp válido com DDD')
    if not body.aceitou_termos:
        raise HTTPException(422, 'Confirme as condições de contratação')
    now = datetime.now(timezone.utc)
    exp = now + timedelta(minutes=60)
    order_id = uuid4().hex
    with store.connect() as db:
        recent = db.execute('SELECT COUNT(*) FROM pedidos WHERE email=? AND criado_em>?',
            (body.email.strip().lower(), (now-timedelta(hours=1)).isoformat())).fetchone()[0]
        if recent >= 5:
            raise HTTPException(429, 'Limite de tentativas atingido. Aguarde uma hora.')
        pack = db.execute("SELECT * FROM catalogo WHERE id=? AND tipo='creation' AND ativo=1", (body.pacote,)).fetchone()
        if not pack:
            raise HTTPException(404, 'Pacote não disponível')
        coupon, discount = store.validate_coupon(db, body.cupom, pack['preco_centavos'])
        if coupon:
            coupon_row = db.execute('SELECT limite_usos,usos FROM cupons WHERE codigo=?', (coupon,)).fetchone()
            if coupon_row['limite_usos'] is not None:
                reserved = db.execute('''SELECT COUNT(*) FROM pedidos WHERE cupom=?
                    AND status='aguardando_pagamento' AND expira_em>?''', (coupon,now.isoformat())).fetchone()[0]
                if coupon_row['usos'] + reserved >= coupon_row['limite_usos']:
                    raise HTTPException(400, 'Cupom sem vagas disponíveis no momento')
        value = int(pack['preco_centavos']) - int(discount or 0)
        if value < 100:
            raise HTTPException(400, 'Não é possível gerar cobrança inferior a R$ 1. Fale com a equipe.')
        db.execute('''INSERT INTO pedidos
            (id,nome,email,whatsapp,pacote,valor_centavos,cupom,desconto_centavos,
             briefing,status,criado_em,expira_em)
            VALUES (?,?,?,?,?,?,?,?,?,'aguardando_pagamento',?,?)''',
            (order_id,body.nome.strip(),body.email.strip().lower(),whatsapp,body.pacote,value,
             coupon,int(discount or 0),body.briefing,now.isoformat(),exp.isoformat()))
    # Registro e valor são definidos pelo servidor, NUNCA pela página do cliente.
    # A criação do pedido NÃO faz cobrança.
    return {'pedido': order_id, 'valor_centavos': value,
            'chave_publica': os.environ['MP_PUBLIC_KEY'].strip(),
            'expira_em': exp.isoformat(), 'metodos': ['pix', 'cartao']}


class PaymentRequest(BaseModel):
    pedido: str = Field(min_length=32, max_length=32, pattern=r'^[0-9a-f]{32}$')
    formData: dict


@router.post('/api/checkout/pagar')
async def submit_payment(body: PaymentRequest, request: Request):
    checkout_access(request, write=True)
    form = body.formData
    if len(str(form)) > 10000:
        raise HTTPException(422, 'Dados de pagamento inválidos')
    method = str(form.get('payment_method_id') or '').lower()
    if not re.fullmatch(r'[a-z][a-z0-9_]{1,39}', method):
        raise HTTPException(422, 'Meio de pagamento inválido')
    # O comerciante escolheu somente Pix ou cartão, não boleto nem wallet.
    forbidden = {'account_money', 'bolbradesco', 'pec', 'paycash', 'rapipago',
                 'pagofacil', 'oxxo', 'pse', 'bapropagos', 'redlink', 'wallet_purchase'}
    if method in forbidden: raise HTTPException(422, 'Escolha Pix ou cartão')
    if method != 'pix' and not re.fullmatch(r'[A-Za-z0-9_-]{8,512}',str(form.get('token') or '')):
        raise HTTPException(422, 'Token do cartão não informado pelo Mercado Pago')
    installments = form.get('installments', 1)
    if not isinstance(installments, int) or isinstance(installments,bool) or not 1<=installments<=18:
        raise HTTPException(422, 'Número de parcelas inválido')
    ident = form.get('payer', {}).get('identification', {}) if isinstance(form.get('payer'),dict) else {}
    if not isinstance(ident,dict): ident={}
    number = re.sub(r'\D','',str(ident.get('number') or ''))
    id_type = str(ident.get('type') or '')
    if number and (not 5 <= len(number) <= 15 or id_type not in ('CPF','CNPJ')):
        raise HTTPException(422, 'Documento inválido')
    now = datetime.now(timezone.utc)
    with store.connect() as db:
        row = db.execute('SELECT * FROM pedidos WHERE id=?', (body.pedido,)).fetchone()
        if not row: raise HTTPException(404, 'Pedido não encontrado')
        if now >= datetime.fromisoformat(row['expira_em']):
            raise HTTPException(410, 'Pedido expirou. Inicie uma nova compra.')
        if row['status'] != 'aguardando_pagamento':
            raise HTTPException(409, 'Esse pedido já teve uma tentativa. Confira o status antes de tentar novamente.')
        # Transição atômica evita cliques simultâneos na mesma compra.
        db.execute("UPDATE pedidos SET status='processando' WHERE id=? AND status='aguardando_pagamento'", (body.pedido,))
        value = row['valor_centavos']
        email = row['email']
        pack = row['pacote']
    data = {'transaction_amount':float(Decimal(value)/100),
            'description': f'CRIASITE - Criacao de site {pack}',
            'external_reference':body.pedido,
            'payment_method_id':method,
            'payer':{'email':email}}
    if number: data['payer']['identification']={'type':id_type,'number':number}
    if method != 'pix':
        data['token']=str(form['token'])
        data['installments']=installments
        issuer = form.get('issuer_id')
        if issuer is not None and str(issuer).isdigit(): data['issuer_id']=int(issuer)
    public_url=os.getenv('CRIASITE_PUBLIC_URL','https://criasite.onrender.com').rstrip('/')
    if not public_url.startswith('https://'):
        raise HTTPException(503,'Configure o endereço HTTPS no servidor')
    data['notification_url']=public_url+'/api/webhooks/mercadopago'
    try:
        async with httpx.AsyncClient(timeout=25.0) as client:
            response=await client.post(MP_API+'/v1/payments', json=data,
                headers={'Authorization':f"Bearer {os.environ['MP_ACCESS_TOKEN'].strip()}",
                         'X-Idempotency-Key':body.pedido,
                         'Content-Type':'application/json'})
        if response.status_code>=400:
            # A tentativa pode ter sido recebida pelo Mercado Pago mesmo quando há erro de rede.
            # Não repetir automaticamente o mesmo pedido. Não inventar aprovação.
            raise HTTPException(502,'Pagamento não confirmado. Confira o pedido antes de repetir.')
        payment=response.json()
        payment_id=str(payment.get('id') or '')
        if not payment_id.isdecimal() or payment.get('external_reference') != body.pedido:
            raise ValueError('Resposta sem referência válida')
        # A confirmação final exige consulta à API autenticada / webhook assinado.
        result_status=str(payment.get('status') or 'pending')
        qr=(payment.get('point_of_interaction') or {}).get('transaction_data') or {}
        return {'pedido':body.pedido,'payment_id':payment_id,'status':result_status,
                'pix_copia_cola':str(qr.get('qr_code') or '') if method=='pix' else '',
                'pix_qr_base64':str(qr.get('qr_code_base64') or '') if method=='pix' else '',
                'mensagem':'Aguarde confirmação do pagamento. Confira o status antes de refazer.'}
    except (httpx.HTTPError,ValueError) as exc:
        # Preserva 'processando' para reconciliação de cobranças incertas.
        raise HTTPException(502,'Não conseguimos verificar o pagamento. Confira o pedido; não pague novamente agora.') from exc


@router.get('/api/checkout/pedido/{order_id}')
def status(order_id:str):
    if not re.fullmatch(r'[0-9a-f]{32}',order_id): raise HTTPException(404,'Pedido não localizado')
    with store.connect() as db:
        row=db.execute('SELECT id,status,valor_centavos FROM pedidos WHERE id=?',(order_id,)).fetchone()
    if row is None: raise HTTPException(404,'Pedido não localizado')
    return {'pedido':row['id'],'status':row['status'],'valor_centavos':row['valor_centavos']}


async def process_payment(payment_id:str, mp_get):
    if not payment_id.isdecimal(): raise HTTPException(400,'ID inválido')
    payment=await mp_get('/v1/payments/'+payment_id)
    order_id=str(payment.get('external_reference') or '')
    if not re.fullmatch(r'[0-9a-f]{32}',order_id):
        return {'ok':True,'tipo':'não relacionado a criação'}
    try:
        value=int(Decimal(str(payment.get('transaction_amount')))*100)
    except (InvalidOperation,TypeError):
        raise HTTPException(503,'Valor do pagamento inválido')
    with store.connect() as db:
        row=db.execute('SELECT * FROM pedidos WHERE id=?',(order_id,)).fetchone()
        if row is None: return {'ok':True,'tipo':'pedido não localizado'}
        if (value!=row['valor_centavos'] or payment.get('currency_id')!='BRL'
            or str(payment.get('id'))!=payment_id):
            raise HTTPException(409,'Pagamento não corresponde ao pedido')
        if row['status']=='pago':return {'ok':True,'status':'pago','duplicado':True}
        new={'approved':'pago','rejected':'recusado','cancelled':'cancelado',
             'refunded':'reembolsado','charged_back':'contestacao',
             'pending':'pendente','in_process':'pendente'}.get(str(payment.get('status') or '').lower(),'pendente')
        db.execute('UPDATE pedidos SET status=?,mp_payment_id=?,atualizado_em=CURRENT_TIMESTAMP WHERE id=?',
                   (new,payment_id,order_id))
        if new=='pago' and row['cupom']:
            db.execute('UPDATE cupons SET usos=usos+1 WHERE codigo=?',(row['cupom'],))
    return {'ok':True,'status':new}


def admin_orders(session=Depends(store.admin_session)):
    with store.connect() as db:
        rows=db.execute('''SELECT id,nome,email,whatsapp,pacote,valor_centavos,cupom,
            desconto_centavos,briefing,status,mp_payment_id,criado_em
            FROM pedidos ORDER BY criado_em DESC LIMIT 200''').fetchall()
    return [dict(row) for row in rows]


router.add_api_route('/api/admin/pedidos',admin_orders,methods=['GET'])
