"""Testes locais de checkout embutido, sem chamar Mercado Pago ou cobrar clientes."""
import asyncio
import os
import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from app import app
import checkout_mp
import store
import db_compat

ENV = {
 'CRIASITE_ENABLE_CHECKOUT':'true',
 'CRIASITE_PERSISTENT_STORAGE_CONFIRMED':'true',
 'MP_PUBLIC_KEY':'TEST-123456789012345',
 'MP_ACCESS_TOKEN':'test_mock_no_real_charges',
 'MP_WEBHOOK_SECRET':'test_signing_secret',
 'CRIASITE_PUBLIC_URL':'https://criasite.onrender.com'
}

class MockResponse:
    status_code = 201
    def __init__(self, payload): self.payload=payload
    def json(self): return self.payload

class MockGateway:
    last_call=None
    def __init__(self,*args,**kwargs): pass
    async def __aenter__(self): return self
    async def __aexit__(self,*args): return None
    async def post(self, url, **kwargs):
        MockGateway.last_call=(url,kwargs)
        return MockResponse({'id': 4567, 'status':'pending',
                             'external_reference':kwargs['json']['external_reference'],
                             'point_of_interaction':{'transaction_data':{'qr_code':'pixcopiacola123',
                                                                        'qr_code_base64':'QUJD'}}})

class TestPaymentBrick(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.client=TestClient(app)
    def setUp(self):
        self.persistent_mock = patch.object(db_compat, 'is_persistent', return_value=True)
        self.persistent_mock.start()
        self.addCleanup(self.persistent_mock.stop)
        with store.connect() as db:
            db.execute('DELETE FROM pedidos')
            db.execute('DELETE FROM cupons')
            db.execute("UPDATE catalogo SET preco_centavos=99900,ativo=1 WHERE id='pro'")

    def sample(self, **kwargs):
        data={'pacote':'pro','cupom':'','nome':'Comprador Teste','email':'comprador@exemplo.com',
             'whatsapp':'15999999999', 'briefing':'Quero site para meu negocio com cinco paginas.',
             'aceitou_termos':True}
        data.update(kwargs)
        return data

    def test_disabled_starts_no_charge(self):
        with patch.dict(os.environ, {'CRIASITE_ENABLE_CHECKOUT':'false'}):
            self.assertFalse(self.client.get('/api/checkout/config').json()['pronto'])
            self.assertEqual(self.client.post('/api/checkout/criar',json=self.sample()).status_code,503)

    def test_price_coupon_sourced_server_and_one_attempt(self):
        with store.connect() as db:
            db.execute("INSERT INTO cupons(codigo,tipo,valor) VALUES ('PROMO10','percent',10)")
        with patch.dict(os.environ,ENV):
            res=self.client.post('/api/checkout/criar',json={**self.sample(cupom='PROMO10'), 'valor_centavos':1})
            self.assertEqual(res.status_code,200,res.text)
            order=res.json()
            self.assertEqual(order['valor_centavos'],89910)
            self.assertNotIn('url_pagamento',order)
            form={'payment_method_id':'pix','payer':{'email':'golpista@fake.com'}}
            with patch.object(checkout_mp.httpx,'AsyncClient',MockGateway):
                paid=self.client.post('/api/checkout/pagar',json={'pedido':order['pedido'],'formData':form})
            self.assertEqual(paid.status_code,200,paid.text)
            self.assertEqual(paid.json()['pix_copia_cola'],'pixcopiacola123')
            url, call=MockGateway.last_call
            self.assertEqual(url,'https://api.mercadopago.com/v1/payments')
            self.assertEqual(call['json']['payer']['email'],self.sample()['email'])
            self.assertEqual(call['json']['transaction_amount'],899.10)
            self.assertEqual(call['headers']['X-Idempotency-Key'],order['pedido'])
            self.assertEqual(self.client.post('/api/checkout/pagar',json={'pedido':order['pedido'],'formData':form}).status_code,409)
            self.assertEqual(self.client.get('/api/checkout/pedido/'+order['pedido']).json()['status'],'processando')

    def test_reject_boleto_and_invalid_card(self):
        with patch.dict(os.environ, ENV):
            r=self.client.post('/api/checkout/criar',json=self.sample())
            order=r.json()['pedido']
            b=self.client.post('/api/checkout/pagar',json={'pedido':order,'formData':{'payment_method_id':'bolbradesco'}})
            self.assertEqual(b.status_code,422)
            b=self.client.post('/api/checkout/pagar',json={'pedido':order,'formData':{'payment_method_id':'visa','installments':1}})
            self.assertEqual(b.status_code,422)
            self.assertEqual(self.client.get('/api/checkout/pedido/'+order).json()['status'],'aguardando_pagamento')

    def test_webhook_verification_changes_status(self):
        with patch.dict(os.environ, ENV):
            r=self.client.post('/api/checkout/criar',json=self.sample())
            order=r.json()['pedido']
        async def get_payment(path):
            assert path=='/v1/payments/4567'
            return {'id':4567,'external_reference':order,
                    'currency_id':'BRL','transaction_amount':999.00,'status':'approved'}
        output=asyncio.run(checkout_mp.process_payment('4567',get_payment))
        self.assertEqual(output['status'],'pago')
        self.assertEqual(self.client.get('/api/checkout/pedido/'+order).json()['status'],'pago')

if __name__=='__main__': unittest.main()
