CRIASITE — PASSO A PASSO PARA INICIANTES — 16/10/2026
===================================================

ESTE PACOTE SERVE PARA PUBLICAR UMA VERSÃO DE TESTE.
NÃO ACEITA PAGAMENTOS REAIS AINDA.

O QUE JA ESTA PRONTO:
- Site e formulário de orçamento com serviços de criação/manutenção.
- Painel em /admin (login, editar preços, criar cupons, visualizar assinaturas).
- Endpoint de prévia de desconto e consulta de parcelas no Mercado Pago.

O QUE AINDA FALTA:
- Checkout real Pix/cartão e criação de assinaturas recorrentes.
- Banco de dados persistente na nuvem e backups.
- Recebimento/validação de pagamentos efetivos, reconciliação periódica, cadastros automáticos.
- Configuração do e-mail que receberá orçamentos; testar ativação no FormSubmit.
- Testes ponta a ponta antes de receber compradores de verdade.

PASSO 1 — GITHUB:
1. Entre em https://github.com e faça login.
2. Crie um repositorio PRIVADO chamado criasite.
3. Extraia este ZIP. Os diretorios backend/ e site/ devem aparecer na RAIZ do repositorio.
   Importante: o GitHub NAO extrai automaticamente arquivos ZIP enviados ao repositório.
   Nao envie .env, *.sqlite3, senhas nem tokens.
4. Pelo computador: abra o repositório > Add file > Upload files, arraste as pastas
   'backend' e 'site' e arquivos de instrução, confirme em Commit changes.
   Pelo celular a selecao de pastas pode ser limitada; se precisar, use um computador
   ou peça ajuda passo a passo com um print da tela.

PASSO 2 — SITE DE TESTE NO RENDER:
1. Entre em https://dashboard.render.com usando GitHub.
2. New > Web Service > vincule o repositório privado CRIASITE.
3. Em Root Directory, escreva: backend
4. Em Language escolha Python 3.
5. Em Build Command: pip install -r requirements.txt
6. Em Start Command: uvicorn app:app --host 0.0.0.0 --port $PORT
7. Se houver opção de Instance Type/Plan: Free (se disponível).
8. Antes de liberar seu painel, configure Environment Variables:
     CRIASITE_ADMIN_USER = seu usuario escolhido
     CRIASITE_ADMIN_PASSWORD_HASH = hash gerado localmente, nao a senha
     CRIASITE_COOKIE_SECURE = true
   Gere o hash abrindo o arquivo gerador_senha_admin.html no seu navegador local,
   digitando a senha forte e copiando SOMENTE o hash.
9. Clique em Deploy. Aguarde o status Live.
10. Abra https://SEU-SITE.onrender.com/ e depois /admin.

AVISO IMPORTANTE: Render Free fica inativo sem visitas; dados SQLite LOCAIS (precos,
cupons, usuarios, status) podem ser PERDIDOS em reinicios/redeploys.
NÃO USE esta configuração para vender de verdade.

PASSO 3 — MERCADO PAGO (SO DEPOIS QUE A HOSPEDAGEM COM BD PERSISTENTE ESTIVER PRONTA):
1. Entre em https://www.mercadopago.com.br/developers/pt e em Suas integrações.
2. Crie/abra uma aplicacao CRIASITE e localize as credenciais de TESTE.
3. Access Token é PRIVADO: fica so no servidor, NUNCA aqui no chat ou GitHub.
4. Criacao de sites: integrar Checkout Pro/Preferences ou Orders, com Pix/cartão.
5. Manutencao: integrar Assinaturas/preapproval com cobrança automatica em cartao.
6. Configurar Webhooks HTTPS e validar cada pagamento na API.
7. Realizar testes: pedido pago, pendente, recusado, cupom, mensalidade atrasada
   e reativação; somente depois usar credenciais de PRODUCAO.

LEMBRETE SOBRE AS REGRAS:
- Vencimento nao pago: SUSPENDER MANUTENÇÃO, nunca tirar o site do ar.
- O Mercado Pago pode tentar novamente cobrança recusada; aguardar confirmação.
- Alterar preço do catálogo não deve alterar assinatura ativa sem concordância.

Nunca publique segredos nem compartilhe prints com dados completos de acesso.
