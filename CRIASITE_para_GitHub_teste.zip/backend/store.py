"""CRIASITE: painel de catálogo, promoções e cupons.

Protótipo local verificável. Previews não cobram nem fazem reservas de cupons.
Implantações comerciais devem usar banco persistente, backup, HTTPS e webhooks.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone, date
from contextlib import contextmanager
from pathlib import Path
from typing import Literal, Optional
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time

from fastapi import Depends, Header, HTTPException, Request, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

SEED = [
    ('start', 'creation', 'Start', 'Landing page profissional', 49900),
    ('pro', 'creation', 'Profissional', 'Site empresarial completo', 99900),
    ('store', 'creation', 'Loja Virtual', 'Catálogo, carrinho e checkout', 199900),
    ('basic', 'maintenance', 'Essencial', 'Acompanhamento básico mensal', 8900),
    ('plus', 'maintenance', 'Profissional', 'Alterações e suporte mensais', 17900),
    ('premium', 'maintenance', 'Premium', 'Acompanhamento prioritário', 29900),
]


@contextmanager
def connect():
    path = Path(os.getenv('CRIASITE_DB_PATH', str(Path(__file__).with_name('data.sqlite3'))))
    path.parent.mkdir(exist_ok=True, parents=True)
    db = sqlite3.connect(path, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA busy_timeout=10000')
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def install():
    with connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS catalogo (
             id TEXT PRIMARY KEY, tipo TEXT NOT NULL CHECK(tipo IN ('creation','maintenance')),
             nome TEXT NOT NULL, descricao TEXT NOT NULL DEFAULT '',
             preco_original_centavos INTEGER NOT NULL CHECK(preco_original_centavos >= 0),
             preco_centavos INTEGER NOT NULL CHECK(preco_centavos >= 0),
             ativo INTEGER NOT NULL DEFAULT 1, atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
        db.execute('''CREATE TABLE IF NOT EXISTS cupons (
             codigo TEXT PRIMARY KEY, tipo TEXT NOT NULL CHECK(tipo IN ('percent','fixed')),
             valor INTEGER NOT NULL, somente_criacao INTEGER NOT NULL DEFAULT 1,
             valido_ate TEXT, limite_usos INTEGER, usos INTEGER NOT NULL DEFAULT 0,
             ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
        db.execute('''CREATE TABLE IF NOT EXISTS sessoes_admin (
             token_hash TEXT PRIMARY KEY, csrf_token TEXT NOT NULL,
             usuario TEXT NOT NULL, expira_em INTEGER NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS tentativas_login (
             ip_hash TEXT PRIMARY KEY, inicio INTEGER NOT NULL, erros INTEGER NOT NULL)''')
        for id_, tipo, nome, desc, preco in SEED:
            db.execute('''INSERT OR IGNORE INTO catalogo
              (id,tipo,nome,descricao,preco_original_centavos,preco_centavos)
              VALUES (?,?,?,?,?,?)''',(id_, tipo, nome, desc, preco, preco))


def today_utc():
    return date.today().isoformat()


def as_public(row):
    d = dict(row)
    d['ativo'] = bool(d['ativo'])
    return d


def table_catalog():
    with connect() as db:
        return [as_public(x) for x in db.execute('SELECT * FROM catalogo ORDER BY CASE tipo WHEN \'creation\' THEN 0 ELSE 1 END, rowid').fetchall()]


def validate_coupon(db, code: str, creation_cents: int):
    code = (code or '').strip().upper()
    if not code: return None, None
    if not re.fullmatch('[A-Z0-9_-]{4,24}', code):
        raise HTTPException(400, 'Código de cupom inválido')
    row = db.execute('SELECT * FROM cupons WHERE codigo=?', (code,)).fetchone()
    if row is None or not row['ativo']:
        raise HTTPException(400, 'Cupom inválido ou desativado')
    if row['valido_ate'] and row['valido_ate'] < today_utc():
        raise HTTPException(400, 'Esse cupom já venceu')
    if row['limite_usos'] is not None and row['usos'] >= row['limite_usos']:
        raise HTTPException(400, 'Esse cupom atingiu o limite de utilização')
    if creation_cents <= 0:
        raise HTTPException(400, 'Esse cupom só se aplica à criação de sites')
    discount = creation_cents * row['valor'] // 100 if row['tipo'] == 'percent' else row['valor']
    return code, min(max(0, discount), creation_cents)


class PreviewIn(BaseModel):
    pacote: Literal['start','pro','store','custom']
    manutencao: Literal['none','basic','plus','premium'] = 'none'
    cupom: str = Field(default='', max_length=24)


def preview(payload: PreviewIn):
    with connect() as db:
        pack = db.execute('SELECT * FROM catalogo WHERE id=? AND tipo=\'creation\' AND ativo=1', (payload.pacote,)).fetchone()
        care = None if payload.manutencao=='none' else db.execute('SELECT * FROM catalogo WHERE id=? AND tipo=\'maintenance\' AND ativo=1', (payload.manutencao,)).fetchone()
        if payload.pacote != 'custom' and pack is None:
            raise HTTPException(404, 'Pacote indisponível')
        if payload.manutencao != 'none' and care is None:
            raise HTTPException(404, 'Plano de manutenção indisponível')
        base = pack['preco_centavos'] if pack else 0
        code, discount = validate_coupon(db, payload.cupom, base)
        return {'pacote': payload.pacote, 'nome_pacote': pack['nome'] if pack else 'Sob orçamento',
                'criacao_centavos': base if pack else None,
                'manutencao': payload.manutencao,
                'manutencao_centavos': care['preco_centavos'] if care else 0,
                'cupom': code, 'desconto_centavos': discount or 0,
                'criacao_com_desconto_centavos': base - (discount or 0) if pack else None,
                'observacao': 'Prévia apenas. Nenhum pagamento foi iniciado ou confirmado. O desconto não se aplica à mensalidade.'}


class LoginIn(BaseModel):
    usuario: str = Field(min_length=1, max_length=120)
    senha: str = Field(min_length=1, max_length=400)


def hash_password(password: str, iterations: int=600000):
    salt = secrets.token_bytes(18)
    result = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
    return f'pbkdf2_sha256${iterations}${salt.hex()}${result.hex()}'


def check_password(password: str, phc: str):
    try:
        scheme, rounds, salt, hashed = phc.split('$')
        if scheme != 'pbkdf2_sha256' or not 150000 <= int(rounds) <= 2000000: return False
        got = hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'), bytes.fromhex(salt), int(rounds))
        return hmac.compare_digest(got, bytes.fromhex(hashed))
    except (TypeError, ValueError, AttributeError): return False


def session_from_request(request: Request, csrf: bool=False):
    token = request.cookies.get('criasite_session','')
    if len(token) < 40: raise HTTPException(401, 'Entre na sua conta de administrador')
    token_hash = hashlib.sha256(token.encode('utf-8')).hexdigest()
    with connect() as db:
        row = db.execute('SELECT * FROM sessoes_admin WHERE token_hash=? AND expira_em>?',(token_hash,int(time.time()))).fetchone()
    if not row: raise HTTPException(401, 'Sessão expirada. Faça login novamente.')
    if csrf and request.method not in ('GET','HEAD','OPTIONS'):
        expected = row['csrf_token']
        if not hmac.compare_digest(request.headers.get('x-csrf-token',''),expected):
            raise HTTPException(403, 'Confirmação de segurança ausente')
    return dict(row)


def admin_session(request: Request): return session_from_request(request, csrf=True)


class ItemUpdate(BaseModel):
    nome: str = Field(min_length=2, max_length=80)
    descricao: str = Field(default='',max_length=240)
    preco_centavos: int = Field(ge=0, le=50000000)
    preco_original_centavos: int = Field(ge=0,le=50000000)
    ativo: bool = True


class CouponCreate(BaseModel):
    codigo: str=Field(min_length=4,max_length=24)
    tipo:Literal['percent','fixed']
    valor:int=Field(ge=1,le=5000000)
    valido_ate:Optional[date]=None
    limite_usos:Optional[int]=Field(default=None,ge=1,le=1000000)
    ativo:bool=True


class CouponUpdate(BaseModel):
    ativo:bool

def attach(app):
    install()

    @app.get('/api/catalogo')
    def catalog_api(): return table_catalog()

    @app.post('/api/checkout/previa')
    def public_preview(item:PreviewIn): return preview(item)

    @app.post('/api/admin/login')
    def login(item: LoginIn, request:Request, response:Response):
        username = os.getenv('CRIASITE_ADMIN_USER', '').strip()
        saved_hash = os.getenv('CRIASITE_ADMIN_PASSWORD_HASH', '').strip()
        if not username or not saved_hash:
            raise HTTPException(503, 'Configure a conta administrativa no servidor antes de entrar')
        ip = (request.client.host if request.client else 'unknown')
        fingerprint = hashlib.sha256(ip.encode()).hexdigest()
        now = int(time.time())
        with connect() as db:
            entry = db.execute('SELECT * FROM tentativas_login WHERE ip_hash=?',(fingerprint,)).fetchone()
            if entry and now-entry['inicio']<900 and entry['erros']>=8:
                raise HTTPException(429, 'Muitas tentativas. Aguarde 15 minutos.')
            valid = hmac.compare_digest(item.usuario, username) and check_password(item.senha,saved_hash)
            if not valid:
                if not entry or now-entry['inicio']>=900:
                    db.execute('INSERT OR REPLACE INTO tentativas_login VALUES(?,?,?)',(fingerprint,now,1))
                else:
                    db.execute('UPDATE tentativas_login SET erros=erros+1 WHERE ip_hash=?',(fingerprint,))
            else:
                db.execute('DELETE FROM tentativas_login WHERE ip_hash=?',(fingerprint,))
            db.execute('DELETE FROM sessoes_admin WHERE expira_em<=?',(now,))
            if valid:
                token = secrets.token_urlsafe(42)
                csrf_token = secrets.token_urlsafe(24)
                db.execute('INSERT INTO sessoes_admin VALUES(?,?,?,?)',
                           (hashlib.sha256(token.encode()).hexdigest(),csrf_token,username,now+12*3600))
        if not valid: raise HTTPException(401, 'Usuário ou senha incorretos')
        response.set_cookie('criasite_session',token,httponly=True,
                            secure=os.getenv('CRIASITE_COOKIE_SECURE','true').lower()!='false',
                            samesite='strict',max_age=12*3600,path='/')
        return {'usuario':username,'csrf_token':csrf_token}

    @app.get('/api/admin/me')
    def me(request: Request):
        session = session_from_request(request)
        return {'usuario':session['usuario'], 'csrf_token':session['csrf_token']}

    @app.post('/api/admin/logout')
    def logout(request:Request, response:Response, session=Depends(admin_session)):
        token = request.cookies.get('criasite_session','')
        with connect() as db:
            db.execute('DELETE FROM sessoes_admin WHERE token_hash=?', (hashlib.sha256(token.encode()).hexdigest(),))
        response.delete_cookie('criasite_session',path='/')
        return {'ok':True}

    @app.get('/api/admin/catalogo')
    def get_catalogo(session=Depends(admin_session)):
        return table_catalog()

    @app.put('/api/admin/catalogo/{item_id}')
    def update_catalog(item_id: str, entry: ItemUpdate, session=Depends(admin_session)):
        if entry.preco_original_centavos < entry.preco_centavos:
            raise HTTPException(422,'Preço original não pode ser menor que o preço atual')
        with connect() as db:
            result=db.execute('''UPDATE catalogo SET nome=?,descricao=?,preco_original_centavos=?,
                  preco_centavos=?,ativo=?,atualizado_em=CURRENT_TIMESTAMP WHERE id=?''',
                  (entry.nome,entry.descricao,entry.preco_original_centavos,entry.preco_centavos,int(entry.ativo),item_id))
            if result.rowcount <1: raise HTTPException(404,'Serviço não encontrado')
        return {'ok':True}

    @app.get('/api/admin/cupons')
    def list_coupons(session=Depends(admin_session)):
        with connect() as db:
            data=[dict(row) for row in db.execute('SELECT * FROM cupons ORDER BY criado_em DESC,codigo').fetchall()]
        for row in data: row['ativo']=bool(row['ativo'])
        return data

    @app.post('/api/admin/cupons')
    def new_coupon(payload:CouponCreate,session=Depends(admin_session)):
        code=payload.codigo.strip().upper()
        if not re.fullmatch('[A-Z0-9_-]{4,24}',code):raise HTTPException(422,'Use apenas letras, números, _ ou -')
        if payload.tipo=='percent' and not 1<=payload.valor<=100:
            raise HTTPException(422,'Desconto percentual deve ser entre 1 e 100')
        if payload.valido_ate and payload.valido_ate<date.today():
            raise HTTPException(422,'A validade não pode estar no passado')
        with connect() as db:
            try:
                db.execute('''INSERT INTO cupons
                  (codigo,tipo,valor,valido_ate,limite_usos,ativo) VALUES(?,?,?,?,?,?)''',
                  (code,payload.tipo,payload.valor,
                   payload.valido_ate.isoformat() if payload.valido_ate else None,
                   payload.limite_usos,int(payload.ativo)))
            except sqlite3.IntegrityError:
                raise HTTPException(409,'Esse cupom já existe')
        return {'ok':True,'codigo':code}

    @app.patch('/api/admin/cupons/{codigo}')
    def switch_coupon(codigo: str, payload: CouponUpdate, session=Depends(admin_session)):
        with connect() as db:
            result = db.execute('UPDATE cupons SET ativo=? WHERE codigo=?',(int(payload.ativo),codigo.strip().upper()))
            if result.rowcount<1: raise HTTPException(404,'Cupom não encontrado')
        return {'ok':True}

    @app.get('/admin')
    def admin_ui():
        return FileResponse(Path(__file__).with_name('admin.html'),headers={'Cache-Control':'no-store'})
