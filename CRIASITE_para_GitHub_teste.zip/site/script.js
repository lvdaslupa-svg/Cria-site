(() => {
  'use strict';
  const packages = {
    start: { name: 'Start', price: 499 },
    pro: { name: 'Profissional', price: 999 },
    store: { name: 'Loja Virtual', price: 1999 },
    custom: { name: 'Projeto personalizado', price: null }
  };
  const maintenance = {
    none: { name: 'Sem manutenção', price: 0 },
    basic: { name: 'Essencial', price: 89 },
    plus: { name: 'Profissional', price: 179 },
    premium: { name: 'Premium', price: 299 }
  };
  const formatMoney = value => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 }).format(value);
  const $ = selector => document.querySelector(selector);
  const form = $('#brief-form');
  const steps = [...document.querySelectorAll('.wizard-step')];
  const headings = ['Vamos nos conhecer', 'Seu pacote e funcionalidades', 'Conte a sua ideia', 'Cuidados após o lançamento'];
  const menuButton = $('#mobile-toggle');
  const nav = $('#nav');
  const output = $('#sending-info');
  const send = $('#send-brief');
  const whatsapp = String(window.CRIASITE_CONFIG?.whatsappComercial || '').replace(/\D/g, '');
  const validWhatsApp = whatsapp.length >= 12 && whatsapp.length <= 13 && whatsapp.startsWith('55');
  const emailOrcamentos = String(window.CRIASITE_CONFIG?.emailOrcamentos || '').trim();
  const emailConfigurado = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailOrcamentos);
  let appliedCode = '';
  let appliedPreview = null;
  let apiReady = false;
  let sending = false;
  let currentStep = 0;

  $('#year').textContent = new Date().getFullYear();

  const moneyCents = cents => formatMoney(cents / 100);
  async function refreshCatalog() {
    try {
      const result = await fetch('/api/catalogo', { headers: {'Accept':'application/json'}, cache: 'no-store' });
      if (!result.ok) throw Error('Catálogo indisponível');
      const data = await result.json();
      if (!Array.isArray(data)) throw Error('Resposta inválida');
      apiReady = true;
      for (const item of data) {
        const val = item.preco_centavos / 100;
        if (item.tipo === 'creation' && packages[item.id]) {
          packages[item.id].price = val;
          packages[item.id].name = item.nome;
          const card = document.querySelector(`[data-package="${item.id}"]`)?.closest('.price-card');
          if (card) {
            const amount = card.querySelector('.amount strong');
            if (amount) amount.textContent = moneyCents(item.preco_centavos);
            const amountBox = card.querySelector('.amount');
            if (amountBox) {
              let original = amountBox.querySelector('.original-price');
              if (!original) { original = document.createElement('small'); original.className='original-price'; amountBox.insertBefore(original,amount); }
              original.textContent = item.preco_original_centavos > item.preco_centavos ? `De ${moneyCents(item.preco_original_centavos)} por` : '';
            }
            card.hidden = !item.ativo;
          }
          const option = $(`#package option[value="${item.id}"]`);
          if (option) { option.textContent = `${item.nome} — a partir de ${moneyCents(item.preco_centavos)}`; option.disabled=!item.ativo; }
        }
        if (item.tipo === 'maintenance' && maintenance[item.id]) {
          maintenance[item.id].price=val;
          maintenance[item.id].name=item.nome;
          const card = document.querySelector(`[data-maintenance="${item.id}"]`)?.closest('.maintenance-card');
          if (card) { const price = card.querySelector('.maintenance-price'); if(price) price.textContent = `${moneyCents(item.preco_centavos)} / mês`; card.hidden=!item.ativo; }
          const radio = $(`input[name="maintenance"][value="${item.id}"]`);
          if (radio) { radio.disabled=!item.ativo; const amount = radio.closest('label')?.querySelector('b'); if(amount) amount.textContent=`${moneyCents(item.preco_centavos)}/mês`; }
        }
      }
      updateSide();
    } catch (_) {
      const note = $('#coupon-status');
      note.textContent = 'Cupons temporariamente indisponíveis. O orçamento ainda pode ser enviado sem desconto.';
      note.classList.add('bad');
    }
  }
  refreshCatalog();

  function resetCoupon() {
    appliedCode = '';
    appliedPreview = null;
    $('#coupon-status').className = '';
    $('#coupon-status').textContent = 'Cupom ainda não aplicado. O desconto vale só para a criação.';
  }
  async function applyCoupon() {
    const code = $('#coupon-code').value.trim().toUpperCase();
    if (!code) { resetCoupon(); updateSide(); buildSummary(); return; }
    if (!apiReady) { error('O sistema de cupons ainda não está disponível neste endereço.'); return; }
    const pack = $('#package').value;
    if (!pack || pack === 'custom') { error('Escolha um pacote com preço definido para utilizar um cupom.', $('#package')); return; }
    const careId = $('input[name="maintenance"]:checked')?.value || 'none';
    try {
      const r = await fetch('/api/checkout/previa', { method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pacote:pack,manutencao:careId,cupom:code}) });
      const data = await r.json();
      if (!r.ok) throw Error(typeof data?.detail==='string'?data.detail:'Cupom não aplicado');
      appliedCode=data.cupom; appliedPreview=data;
      const el=$('#coupon-status');el.className='ok';el.textContent=`Cupom ${appliedCode} aplicado: ${moneyCents(data.desconto_centavos)} de desconto na criação.`;
      updateSide();buildSummary();
    } catch(e) { resetCoupon(); $('#coupon-status').textContent=e.message;$('#coupon-status').className='bad'; updateSide();buildSummary(); }
  }
  $('#apply-coupon').addEventListener('click',applyCoupon);
  $('#coupon-code').addEventListener('input',()=>{resetCoupon();updateSide();if(currentStep===3)buildSummary()});
  menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
  });
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Abrir menu');
  }));

  function choicePackage(id) {
    $('#package').value = id;
    if (id === 'store') $('#project-kind').value = 'Loja virtual';
    else if (id === 'start') $('#project-kind').value = 'Landing page';
    else if (id === 'pro') $('#project-kind').value = 'Site institucional';
    resetCoupon();updateSide();
    showStep(1);
    $('#orcamento').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  document.querySelectorAll('[data-package]').forEach(btn => btn.addEventListener('click', () => choicePackage(btn.dataset.package)));
  document.querySelectorAll('[data-type]').forEach(link => link.addEventListener('click', () => {
    $('#project-kind').value = link.dataset.type;
    updateSide();
  }));
  document.querySelectorAll('[data-maintenance]').forEach(btn => btn.addEventListener('click', () => {
    const option = $(`input[name="maintenance"][value="${btn.dataset.maintenance}"]`);
    option.checked = true;
    updateSide();
    showStep(3);
    $('#orcamento').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }));

  function showStep(index) {
    currentStep = index;
    steps.forEach((element, i) => { element.hidden = i !== index; });
    $('#wizard-count').textContent = `ETAPA ${index + 1} DE ${steps.length}`;
    $('#wizard-heading').textContent = headings[index];
    $('#wizard-progress').style.width = `${((index + 1) / steps.length) * 100}%`;
    $('#prev-step').hidden = index === 0;
    $('#next-step').hidden = index === steps.length - 1;
    send.hidden = index !== steps.length - 1;
    $('#after-actions').hidden = index !== steps.length - 1;
    if (index === steps.length - 1) buildSummary();
    updateSide();
    $('#toast').hidden = true;
  }

  function error(message, element) {
    const toast = $('#toast');
    toast.textContent = message;
    toast.hidden = false;
    if (element) {
      element.setAttribute('aria-invalid', 'true');
      element.focus({ preventScroll: false });
    }
  }
  function validStep(index) {
    const step = steps[index];
    for (const input of step.querySelectorAll('input[required],select[required],textarea[required],input[type="email"]')) {
      input.removeAttribute('aria-invalid');
      if (input.type === 'checkbox' && !input.checked) { error('Confirme o consentimento para continuar.', input); return false; }
      if (input.required && input.type !== 'checkbox' && !input.value.trim()) { error('Preencha os campos obrigatórios para continuar.', input); return false; }
      if (!input.checkValidity()) { error('Confira as informações deste campo.', input); return false; }
    }
    if (index === 0) {
      if ($('#contact-preference').value === 'E-mail' && !$('#email').value.trim()) { error('Para contato por e-mail, preencha seu endereço de e-mail.', $('#email')); return false; }
      const phone = $('#phone');
      const digits = phone.value.replace(/\D/g, '');
      if (digits.length < 10 || digits.length > 13) { error('Digite um WhatsApp válido com DDD.', phone); return false; }
    }
    return true;
  }

  $('#next-step').addEventListener('click', () => {
    if (!validStep(currentStep)) return;
    showStep(Math.min(steps.length - 1, currentStep + 1));
  });
  $('#prev-step').addEventListener('click', () => showStep(Math.max(0, currentStep - 1)));
  form.addEventListener('input', event => {
    if (event.target instanceof HTMLElement) event.target.removeAttribute('aria-invalid');
    updateSide();
    if (currentStep === 3) buildSummary();
    $('#toast').hidden = true;
  });
  form.addEventListener('change', e => { if (e.target?.name === 'package' || e.target?.name === 'maintenance') resetCoupon(); updateSide(); if (currentStep === 3) buildSummary(); });

  function selections() {
    const packageId = $('#package').value;
    const careId = $('input[name="maintenance"]:checked')?.value || 'none';
    return { pack: packages[packageId] || null, care: maintenance[careId] || maintenance.none };
  }
  function updateSide() {
    const { pack, care } = selections();
    $('#side-creation').textContent = pack ? (pack.price === null ? 'Sob orçamento' : (appliedPreview ? `${moneyCents(appliedPreview.criacao_com_desconto_centavos)} com cupom` : `A partir de ${formatMoney(pack.price)}`)) : 'Escolha um pacote';
    $('#side-maintenance').textContent = care.price === 0 ? 'Sem manutenção' : `${formatMoney(care.price)}/mês`;
  }
  function data() { return new FormData(form); }
  function field(name, fallback = 'Não informado') {
    const value = String(data().get(name) || '').trim();
    return value || fallback;
  }
  function summaryValues() {
    const { pack, care } = selections();
    return [
      ['Cliente', field('fullName')],
      ['Empresa', field('company')],
      ['WhatsApp', field('phone')],
      ['Contato preferido', field('contactPreference')],
      ['Pacote de criação', pack ? `${pack.name} — ${pack.price === null ? 'sob orçamento' : 'a partir de ' + formatMoney(pack.price)}` : 'Não selecionado'],
      ['Tipo de projeto', field('projectKind')],
      ['Manutenção mensal', `${care.name} — ${formatMoney(care.price)}/mês`],
      ['Cupom aplicado', appliedPreview ? `${appliedCode}: -${moneyCents(appliedPreview.desconto_centavos)}` : 'Nenhum'],
      ['Criação após desconto', appliedPreview ? moneyCents(appliedPreview.criacao_com_desconto_centavos) : 'A confirmar']
    ];
  }
  function buildSummary() {
    const el = $('#form-summary');
    el.replaceChildren();
    const dl = document.createElement('dl');
    summaryValues().forEach(([label, value]) => {
      const row = document.createElement('div');
      row.className = 'summary-row';
      const dt = document.createElement('dt'); dt.textContent = label;
      const dd = document.createElement('dd'); dd.textContent = value;
      row.append(dt, dd); dl.appendChild(row);
    });
    el.appendChild(dl);
  }
  function makeBriefing() {
    const { pack, care } = selections();
    const extras = data().getAll('features');
    return [
      '📋 *NOVO PEDIDO DE ORÇAMENTO — CRIASITE*',
      'Do seu jeito, do seu negócio.',
      '',
      '*1. DADOS DO CLIENTE*',
      `Nome: ${field('fullName')}`,
      `WhatsApp: ${field('phone')}`,
      `E-mail: ${field('email')}`,
      `Preferência de contato: ${field('contactPreference')}`,
      `Melhor horário para contato: ${field('bestTime')}`,
      `Empresa/Projeto: ${field('company')}`,
      `Ramo de atividade: ${field('industry')}`,
      '',
      '*2. CRIAÇÃO DO SITE*',
      `Pacote: ${pack?.name || 'Não selecionado'}`,
      `Preço inicial da criação: ${pack?.price == null ? 'A combinar' : formatMoney(pack.price)}`,
      `Cupom de desconto verificado: ${appliedCode || 'Nenhum'}`,
      `Desconto na criação: ${appliedPreview ? moneyCents(appliedPreview.desconto_centavos) : 'R$ 0,00'}`,
      `Criação após desconto: ${appliedPreview ? moneyCents(appliedPreview.criacao_com_desconto_centavos) : 'Sob orçamento'}`,
      `Tipo de site: ${field('projectKind')}`,
      `Funcionalidades desejadas: ${extras.length ? extras.join(', ') : 'A definir'}`,
      '',
      '*3. IDEIA E IDENTIDADE VISUAL*',
      `Estilo: ${field('visualStyle')}`,
      `Logo e identidade: ${field('brandMaterial')}`,
      `Cores: ${field('colorChoice')}`,
      `Referências: ${field('references')}`,
      `Domínio: ${field('domain')}`,
      `Prazo: ${field('deadline')}`,
      `Descrição completa:\n${field('description')}`,
      '',
      '*4. MANUTENÇÃO APÓS A ENTREGA*',
      `Plano: ${care.name}`,
      `Mensalidade sugerida: ${formatMoney(care.price)} / mês`,
      `Outras observações: ${field('notes')}`,
      '',
      '⚠️ Valores iniciais sujeitos à confirmação. A criação tem pagamento único; manutenção é opcional e mensal. Este pedido não constitui contratação nem pagamento.'
    ].join('\n');
  }
  async function copyBrief() {
    const message = makeBriefing();
    try {
      await navigator.clipboard.writeText(message);
    } catch (_) {
      const temp = document.createElement('textarea');
      temp.value = message;
      temp.style.position = 'fixed'; temp.style.left = '-9999px';
      document.body.appendChild(temp); temp.select();
      const didCopy = document.execCommand('copy');
      temp.remove();
      if (!didCopy) { error('Não consegui copiar. Use o botão de baixar o briefing.'); return; }
    }
    const toast = $('#toast'); toast.textContent = 'Briefing copiado! Agora você pode colar onde preferir.'; toast.hidden = false;
  }
  function downloadBrief() {
    const blob = new Blob([makeBriefing()], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const name = field('fullName', 'cliente').replace(/[^a-z\d -]/gi, '').trim().replace(/\s+/g, '-').slice(0, 32) || 'cliente';
    link.download = `criasite-briefing-${name}.txt`;
    document.body.appendChild(link);
    link.click(); link.remove();
    URL.revokeObjectURL(url);
    const toast = $('#toast'); toast.textContent = 'Briefing salvo em um arquivo de texto.'; toast.hidden = false;
  }
  $('#copy-brief').addEventListener('click', copyBrief);
  $('#download-brief').addEventListener('click', downloadBrief);

  // O site é estático: FormSubmit recebe o pedido via AJAX e encaminha ao e-mail
  // configurado. A primeira submissão requer ativação pelo titular do e-mail.
  send.textContent = 'Enviar pedido por e-mail ↗';
  if (emailConfigurado) {
    output.textContent = 'Ao enviar, o briefing irá para nossa equipe por e-mail. Não é necessário abrir o WhatsApp. Entraremos em contato depois, de acordo com sua preferência.';
  } else {
    output.textContent = 'ENVIO AINDA NÃO CONFIGURADO: a equipe precisa definir o e-mail de recebimento. Você pode copiar ou baixar seu pedido enquanto isso.';
    output.classList.add('notice-alert');
  }

  $('#new-brief').addEventListener('click', () => {
    form.reset();
    $('#brief-success').hidden = true;
    form.hidden = false;
    $('#after-actions').hidden = true;
    $('#toast').hidden = true;
    updateSide();
    showStep(0);
  });

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (sending) return;
    for (let i = 0; i < steps.length; i++) {
      if (!validStep(i)) { showStep(i); validStep(i); return; }
    }
    if (appliedCode) {
      // Verifique novamente no servidor: preço e cupom não são confiáveis no navegador.
      const result=await fetch('/api/checkout/previa',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pacote:$('#package').value,manutencao:$('input[name="maintenance"]:checked')?.value||'none',cupom:appliedCode})}).catch(()=>null);
      if (!result || !result.ok) { resetCoupon(); error('O cupom não pôde ser confirmado novamente. Confira o código e clique em Aplicar cupom.');return; }
      appliedPreview=await result.json();
    }
    if (!emailConfigurado) {
      error('O envio automático ainda não foi ativado. A equipe precisa configurar o e-mail de recebimento. Você pode baixar o briefing.');
      return;
    }

    sending = true;
    send.disabled = true;
    send.textContent = 'Enviando pedido…';
    output.textContent = 'Aguarde, enviando suas informações de forma segura…';
    $('#toast').hidden = true;

    const { pack, care } = selections();
    const payload = {
      _subject: `CRIASITE | Novo orçamento — ${field('fullName')}`,
      _captcha: 'false',
      _honey: $('#website-check').value,
      name: field('fullName'),
      email: $('#email').value.trim(),
      telefone_whatsapp: field('phone'),
      contato_preferido: field('contactPreference'),
      melhor_horario: field('bestTime'),
      empresa: field('company'),
      pacote: pack ? `${pack.name} — ${pack.price === null ? 'sob orçamento' : formatMoney(pack.price)}` : 'Não informado',
      manutencao: `${care.name} — ${formatMoney(care.price)}/mês`,
      resumo_completo: makeBriefing()
    };
    // Reply-To do e-mail, quando o cliente fornece endereço válido.
    if (payload.email) payload._replyto = payload.email;

    try {
      const response = await fetch(`https://formsubmit.co/ajax/${encodeURIComponent(emailOrcamentos)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload)
      });
      let result = null;
      try { result = await response.json(); } catch (_) { /* HTTP sem JSON */ }
      if (!response.ok || !result || (result.success !== true && String(result.success).toLowerCase() !== 'true')) {
        throw new Error('Serviço de e-mail não confirmou a solicitação.');
      }

      form.hidden = true;
      $('#after-actions').hidden = true;
      $('#wizard-count').textContent = 'PEDIDO ENCAMINHADO';
      $('#wizard-heading').textContent = 'Pronto, seu pedido foi registrado';
      $('#wizard-progress').style.width = '100%';
      const success = $('#brief-success');
      success.hidden = false;
      if (validWhatsApp) {
        const link = $('#success-whatsapp');
        link.href = `https://wa.me/${whatsapp}?text=${encodeURIComponent('Olá, enviei um pedido de orçamento pelo site da CRIASITE. Gostaria de conversar sobre meu projeto.')}`;
        link.hidden = false;
      }
      success.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch (err) {
      // Não afirmar que o e-mail chegou quando a confirmação do servidor falhar.
      error('Não foi possível confirmar o envio agora. Tente novamente em alguns instantes. Se preferir, baixe o briefing para não perder suas informações.');
      output.textContent = 'Não recebemos confirmação do serviço de e-mail. Seus dados continuam preenchidos.';
    } finally {
      sending = false;
      send.disabled = false;
      send.textContent = 'Enviar pedido por e-mail ↗';
    }
  });
  showStep(0);
})();
