/* CRIASITE — CONFIGURAÇÕES PÚBLICAS DO SITE
   1) Insira o endereço que RECEBERÁ os pedidos em emailOrcamentos.
   2) Publique o site e envie um pedido de teste para ativar o FormSubmit.
   3) Abra o e-mail de ativação enviado pelo FormSubmit e confirme o destinatário.
   4) Faça outro pedido de teste e confirme o recebimento na caixa de entrada/spam.

   ATENÇÃO: essa integração usa o serviço externo FormSubmit.co. O endereço
   configurado fica visível no código-fonte do site (público). Não insira
   senhas, tokens, credenciais SMTP nem dados sigilosos aqui.
   O envio real NÃO funciona até preencher o e-mail e confirmar a ativação.
*/
window.CRIASITE_CONFIG = {
  emailOrcamentos: '',  // Ex.: 'contato@suaempresa.com.br' (substitua pelo SEU e-mail)
  whatsappComercial: '' // Opcional. Ex.: '5515999999999' (55 + DDD + número)
};
